/****************************************************************************
** Meta object code from reading C++ file 'DmesgCall.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../ccoo-master/DmesgCall.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'DmesgCall.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_DmesgCall_t {
    QByteArrayData data[13];
    char stringdata0[100];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DmesgCall_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DmesgCall_t qt_meta_stringdata_DmesgCall = {
    {
QT_MOC_LITERAL(0, 0, 9), // "DmesgCall"
QT_MOC_LITERAL(1, 10, 4), // "call"
QT_MOC_LITERAL(2, 15, 0), // ""
QT_MOC_LITERAL(3, 16, 3), // "URL"
QT_MOC_LITERAL(4, 20, 8), // "call_dev"
QT_MOC_LITERAL(5, 29, 8), // "call_cpu"
QT_MOC_LITERAL(6, 38, 8), // "call_mem"
QT_MOC_LITERAL(7, 47, 10), // "revert_led"
QT_MOC_LITERAL(8, 58, 9), // "blink_led"
QT_MOC_LITERAL(9, 68, 12), // "check_status"
QT_MOC_LITERAL(10, 81, 3), // "led"
QT_MOC_LITERAL(11, 85, 12), // "booltostring"
QT_MOC_LITERAL(12, 98, 1) // "i"

    },
    "DmesgCall\0call\0\0URL\0call_dev\0call_cpu\0"
    "call_mem\0revert_led\0blink_led\0"
    "check_status\0led\0booltostring\0i"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DmesgCall[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // methods: name, argc, parameters, tag, flags
       1,    1,   54,    2, 0x02 /* Public */,
       4,    0,   57,    2, 0x02 /* Public */,
       5,    0,   58,    2, 0x02 /* Public */,
       6,    0,   59,    2, 0x02 /* Public */,
       7,    0,   60,    2, 0x02 /* Public */,
       8,    0,   61,    2, 0x02 /* Public */,
       9,    1,   62,    2, 0x02 /* Public */,
      11,    1,   65,    2, 0x02 /* Public */,

 // methods: parameters
    QMetaType::QString, QMetaType::QString,    3,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool, QMetaType::Bool,   10,
    QMetaType::QString, QMetaType::Bool,   12,

       0        // eod
};

void DmesgCall::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        DmesgCall *_t = static_cast<DmesgCall *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: { QString _r = _t->call((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 1: { QString _r = _t->call_dev();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 2: { QString _r = _t->call_cpu();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 3: { QString _r = _t->call_mem();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 4: _t->revert_led(); break;
        case 5: _t->blink_led(); break;
        case 6: { bool _r = _t->check_status((*reinterpret_cast< bool(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 7: { QString _r = _t->booltostring((*reinterpret_cast< bool(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

const QMetaObject DmesgCall::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_DmesgCall.data,
      qt_meta_data_DmesgCall,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *DmesgCall::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DmesgCall::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_DmesgCall.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int DmesgCall::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
