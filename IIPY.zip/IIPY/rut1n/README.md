For the dignity of life, it is necessary to be able to refuse small pleasures and considerable ones too ... Being able to apologize, admit a mistake to others is better than lying.

When deceiving, a person deceives himself first of all, for he thinks that he lied successfully, and people understood, and because of delicacy they were silent.

Life is first of all creativity, but this does not mean that every person must live as an artist, ballerina or scientist in order to live. You can create just a good atmosphere around you. A person can bring with him an atmosphere of suspicion, some kind of painful silence, and can immediately bring joy, light. This is creativity.


# IIPY
